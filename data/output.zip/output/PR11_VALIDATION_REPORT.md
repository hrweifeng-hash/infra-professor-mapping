# PR11 Validation Report

Generated: 2026-07-03T03:08:57.684493+00:00

## Summary

- US professors in universe: **4570**

## Top100 Comparison (Legacy vs PR11 Ranking)

- Overlap: **30/100**
- Added to Top100: **70**
- Removed from Top100: **70**

### Added (infra affinity boost)
- Scott Shenker
- Remzi H. Arpaci-Dusseau
- Gregory R. Ganger
- Andrea C. Arpaci-Dusseau
- Sylvia Ratnasamy
- Natacha Crooks
- Peter R. Pietzuch
- Jason Nieh
- Ming Liu 0027
- Christos Kozyrakis
- Ramesh Govindan
- T. S. Eugene Ng
- Yifan Qiao 0002
- Alex C. Snoeren
- Sam H. Noh

### Removed (lower infra affinity)
- Rex Ying
- Sham M. Kakade
- Furong Huang
- Christopher RÃ©
- Jiawei Han 0001
- Jure Leskovec
- Tong Geng
- Venkatesh Saligrama
- Xipeng Shen
- Adam Wierman
- Yuandong Tian
- Yanzhi Wang 0001
- Willie Neiswanger
- David Brooks 0001
- Pieter Abbeel

### Largest rank changes (still in Top100)

| Name | Legacy Rank | New Rank | Δ |
| --- | --- | --- | --- |
| Peng Huang 0005 | 95 | 9 | +86 |
| Vincent Liu 0001 | 89 | 4 | +85 |
| Rachit Agarwal 0001 | 90 | 5 | +85 |
| Philip S. Yu | 14 | 97 | -83 |
| David P. Woodruff | 11 | 94 | -83 |
| Mingyi Hong 0001 | 13 | 96 | -83 |
| Joshua B. Tenenbaum | 15 | 98 | -83 |
| Heng Huang 0001 | 12 | 95 | -83 |
| Zhenyu Zhang 0015 | 16 | 99 | -83 |
| Sijia Liu 0001 | 17 | 100 | -83 |
| Ang Chen 0001 | 91 | 11 | +80 |
| Michael I. Jordan | 10 | 85 | -75 |
| Song Han 0003 | 9 | 80 | -71 |
| Guoqing Harry Xu | 92 | 31 | +61 |
| Josep Torrellas | 7 | 62 | -55 |

## Infrastructure Affinity (Top100)

- Mean: **77%**
- Median: **91%**
- Range: 0% – 100%
- Professors with ≥50% infra papers: **82**
- Professors with <30% infra papers: **13**

## Professor Role Estimates (Heuristic)

- **faculty**: 100 (100.0%)

**Assessment:** LOW — 100% of Top100 classify as faculty from existing affiliation/homepage signals. Dedicated Professor Identification is not yet a priority.

## Future Ranking Signals (Not Implemented in PR11)

| Signal | Data Available | Recruiter Value | Notes |
| --- | --- | --- | --- |
| Recent activity (last 2 years) | True | High — surfaces actively publishing candidates | yearly_publications already computed; weight recent papers |
| Venue diversity | True | Medium — breadth vs single-venue specialists | venue_distribution length / entropy |
| Long-term impact / seniority | True | Medium — distinguishes established leaders | active_years, first_publication_year spread |
| Productivity trend | True | Medium — rising vs declining output | productivity_analyzer exists but not in overall_score |
| Infrastructure affinity (PR11) | True | High — core deliverable quality fix | Implemented as 30% of overall_score |

## Recommendations

- Infrastructure Affinity is now an explicit, exportable ranking feature — use it to explain why infra-focused professors rank higher.
- Research summaries are generated only for the final Top100 via the pluggable summaries/ pipeline; swap StubLLMProvider when API keys are ready.
- 13 Top100 professors still have <30% infra affinity — review manually before stakeholder demo.
- LOW — 100% of Top100 classify as faculty from existing affiliation/homepage signals. Dedicated Professor Identification is not yet a priority.
